﻿// PkgCmdID.cs
// MUST match PkgCmdID.h

namespace devcoach.Tools
{
    static class PkgCmdIDList
    {
        public const uint cmdidToggleKarmaVsUnit = 0x300;
        public const uint cmdidOptionsKarmaVsUnit = 0x301;
    };
}